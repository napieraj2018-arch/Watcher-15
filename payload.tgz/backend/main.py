from __future__ import annotations
import asyncio, base64, hashlib, hmac, json, os, secrets, time, uuid
from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlsplit
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import ValidationError
from starlette.middleware.trustedhost import TrustedHostMiddleware
from . import __version__
from .models import CaseInput
from .imaging import prepare_image, ImageInputError
from .provider import OpenAIVisionProvider,ProviderError,validate_references
from .clinical import interpret
from .prompt import PROMPT_VERSION
ROOT=Path(__file__).resolve().parent.parent
MAX_BODY=72*1024*1024

@dataclass
class Settings:
    api_key:str=field(default_factory=lambda:os.getenv('OPENAI_API_KEY',''),repr=False)
    model:str=field(default_factory=lambda:os.getenv('VISION_MODEL','gpt-6-astra'))
    access_code:str=field(default_factory=lambda:os.getenv('CLINIC_ACCESS_CODE',''),repr=False)
    session_secret:str=field(default_factory=lambda:os.getenv('SESSION_SECRET',''),repr=False)
    origin:str=field(default_factory=lambda:os.getenv('APP_ORIGIN',os.getenv('RENDER_EXTERNAL_URL','')).rstrip('/'))
    secure:bool=True
    session_lifetime:int=14*24*60*60
    max_per_day:int=50

class BoundedBody:
    def __init__(self,app): self.app=app
    async def __call__(self,scope,receive,send):
        if scope['type']!='http' or scope.get('method') not in ('POST','PUT','PATCH'):
            return await self.app(scope,receive,send)
        size=0;chunks=[]
        while True:
            part=await receive()
            if part['type']=='http.disconnect':return
            data=part.get('body',b'');size+=len(data)
            if size>MAX_BODY:
                return await JSONResponse({'error':'TOO_LARGE','message':'Zdjęcia przekraczają łączny limit 72 MB.'},413)(scope,receive,send)
            chunks.append(data)
            if not part.get('more_body',False):break
        body=b''.join(chunks); consumed=False
        async def bounded():
            nonlocal consumed
            if not consumed:
                consumed=True;return {'type':'http.request','body':body,'more_body':False}
            return await receive()
        return await self.app(scope,bounded,send)

class Limits:
    def __init__(self): self.events=defaultdict(deque)
    def allow(self,key,limit,window):
        now=time.monotonic();q=self.events[key]
        while q and q[0]<now-window:q.popleft()
        if len(q)>=limit:return False
        q.append(now)
        if len(self.events)>5000:
            for k in list(self.events):
                if not self.events[k] or self.events[k][-1]<now-86400:self.events.pop(k,None)
        return True

def create_app(cfg:Settings|None=None,provider=None):
    cfg=cfg or Settings(); hostname=urlsplit(cfg.origin).hostname
    configured_auth=len(cfg.access_code)>=16 and len(cfg.session_secret)>=32 and bool(hostname) and (not cfg.secure or cfg.origin.startswith('https://'))
    app=FastAPI(title='OkoVet Mobile',version=__version__,docs_url=None,redoc_url=None,openapi_url=None)
    app.add_middleware(BoundedBody)
    app.add_middleware(TrustedHostMiddleware,allowed_hosts=[hostname] if hostname else ['localhost','127.0.0.1','testserver'])
    engine=provider or OpenAIVisionProvider(cfg.api_key,cfg.model)
    limits=Limits();analysis_lock=asyncio.Lock();inflight=set();completed=set(); revoked={}; live_success=False
    app.state.settings=cfg
    def signed(value):return hmac.new(cfg.session_secret.encode(),value.encode(),hashlib.sha256).hexdigest()
    def issue():
        sid=secrets.token_urlsafe(24); exp=int(time.time())+cfg.session_lifetime
        access_tag=hashlib.sha256(cfg.access_code.encode()).hexdigest()[:16]
        payload=f'{sid}.{exp}.{access_tag}'
        return payload+'.'+signed(payload)
    def auth(request):
        if not configured_auth:return None
        token=request.cookies.get('okovet_session','')
        try:
            sid,exp,tag,sig=token.split('.')
            if sid in revoked or int(exp)<time.time() or tag!=hashlib.sha256(cfg.access_code.encode()).hexdigest()[:16]:return None
            if not hmac.compare_digest(sig,signed(f'{sid}.{exp}.{tag}')):return None
            return sid
        except (ValueError,TypeError):return None
    def csrf(sid): return signed('csrf:'+sid)
    @app.middleware('http')
    async def security(request,call_next):
        mutating=request.method not in ('GET','HEAD','OPTIONS')
        if request.url.path.startswith('/api/') and mutating:
            if request.headers.get('origin')!=cfg.origin or request.headers.get('sec-fetch-site')=='cross-site':
                return JSONResponse({'error':'ORIGIN','message':'Niedozwolone źródło żądania.'},403)
        if request.url.path.startswith('/api/') and request.url.path not in ('/api/status','/api/login'):
            sid=auth(request)
            if not sid:return JSONResponse({'error':'LOGIN_REQUIRED','message':'Zaloguj się kodem kliniki.'},401)
            if mutating and not hmac.compare_digest(request.headers.get('x-csrf-token',''),csrf(sid)):
                return JSONResponse({'error':'CSRF','message':'Sesja wymaga odświeżenia.'},403)
        response=await call_next(request)
        response.headers.update({'X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Referrer-Policy':'no-referrer',
          'Permissions-Policy':'camera=(self), microphone=(), geolocation=()',
          'Content-Security-Policy':"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' blob: data:; connect-src 'self'; font-src 'self'; media-src 'self' blob:; object-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"})
        response.headers['Cache-Control']='no-store' if request.url.path.startswith('/api/') else 'no-cache'
        if cfg.secure:response.headers['Strict-Transport-Security']='max-age=31536000'
        return response
    @app.exception_handler(ProviderError)
    async def error(_request,exc):
        return JSONResponse({'error':exc.code,'message':exc.message,'image_inference_completed':False},exc.status)
    @app.get('/healthz')
    async def healthz():return {'status':'ok','version':__version__}
    @app.get('/api/status')
    async def status(request:Request):
        sid=auth(request)
        return {'version':__version__,'authenticated':bool(sid),'access_configured':configured_auth,
          'analysis_configured':bool(cfg.api_key) and configured_auth,'live_inference_verified':live_success,
          'model':cfg.model,'clinically_validated':False,'csrf_token':csrf(sid) if sid else None,
          'maximum_images':6,'inference_location':'cloud','storage':'device_opt_in_no_server_patient_storage'}
    @app.post('/api/login')
    async def login(request:Request):
        if not configured_auth:raise ProviderError('SETUP_REQUIRED','Dostęp do kliniki nie został jeszcze skonfigurowany.',503)
        ip=request.client.host if request.client else 'unknown'
        if not limits.allow('login:'+ip,8,900):raise ProviderError('RATE_LIMIT','Zbyt wiele prób. Spróbuj ponownie później.',429)
        try:
            body=await request.json();password=body.get('code','')
            if not isinstance(password,str) or len(password)>256:raise ValueError()
        except (ValueError,AttributeError):raise ProviderError('LOGIN_FORMAT','Nieprawidłowe dane logowania.',400)
        if not hmac.compare_digest(hashlib.sha256(password.encode()).digest(),hashlib.sha256(cfg.access_code.encode()).digest()):
            raise ProviderError('LOGIN_FAILED','Nieprawidłowy kod dostępu.',401)
        token=issue();response=JSONResponse({'ok':True})
        response.set_cookie('okovet_session',token,max_age=cfg.session_lifetime,secure=cfg.secure,httponly=True,samesite='strict',path='/')
        return response
    @app.post('/api/logout')
    async def logout(request:Request):
        sid=auth(request)
        revoked[sid]=time.time()+cfg.session_lifetime
        for old in list(revoked):
            if revoked[old]<time.time():revoked.pop(old,None)
        response=JSONResponse({'ok':True});response.delete_cookie('okovet_session',path='/',secure=cfg.secure,httponly=True,samesite='strict');return response
    async def read_case(request):
        try:form=await request.form(max_files=6,max_fields=2,max_part_size=16384)
        except Exception as exc:raise ProviderError('UPLOAD_FORMAT','Nieprawidłowe przesyłanie zdjęć.',400) from exc
        try:
            raw_case=form.get('case','')
            if not isinstance(raw_case,str):raise ProviderError('INVALID_CASE','Nieprawidłowy formularz.',422)
            try:case=CaseInput.model_validate_json(raw_case)
            except (ValueError,ValidationError) as exc:raise ProviderError('INVALID_CASE','Sprawdź gatunek, oko, tryb oraz wpisane pomiary.',422) from exc
            uploads=form.getlist('images')
            if not 1<=len(uploads)<=6:raise ProviderError('IMAGE_COUNT','Dodaj od 1 do 6 zdjęć jednego oka / tej samej próbki.',422)
            images=[]; hashes=set()
            for idx,upload in enumerate(uploads,1):
                if not hasattr(upload,'read'):raise ProviderError('INVALID_IMAGE','Nieprawidłowy plik.',400)
                raw=await upload.read(20*1024*1024+1)
                try:image=await asyncio.to_thread(prepare_image,raw,idx)
                except ImageInputError as exc:raise ProviderError('INVALID_IMAGE',str(exc),422) from exc
                if image.metadata['original_sha256'] in hashes:raise ProviderError('DUPLICATE','Dodano ten sam plik więcej niż raz.',422)
                hashes.add(image.metadata['original_sha256']);images.append(image)
            return case,images
        finally:await form.close()
    @app.post('/api/analyze')
    async def analyze(request:Request):
        nonlocal live_success
        if not cfg.api_key and provider is None:raise ProviderError('NOT_CONFIGURED','Silnik obrazu oczekuje na aktywację. Żadne zdjęcia nie trafiły do AI.',503)
        sid=auth(request)
        rid=request.headers.get('x-request-id','')
        try:uuid.UUID(rid)
        except ValueError:raise ProviderError('REQUEST_ID','Brak identyfikatora analizy.',400)
        key=(sid,rid)
        if key in completed or key in inflight:raise ProviderError('DUPLICATE_REQUEST','To zapytanie było już przyjęte. Nie naliczono drugiej analizy.',409)
        if analysis_lock.locked():raise ProviderError('BUSY','Inna analiza trwa. Nie uruchomiono drugiego zapytania.',409)
        async with analysis_lock:
            inflight.add(key)
            try:
                case,images=await read_case(request)
                if not case.share_images:raise ProviderError('CONSENT','Potrzebna jednorazowa zgoda na przesyłanie zdjęć do silnika AI.',400)
                if any(i.metadata['technical_hard_stop'] for i in images):
                    raise ProviderError('IMAGE_QUALITY','Co najmniej jedno zdjęcie jest zbyt małe albo niemal jednolite. Zastąp je ostrzejszym ujęciem.',422)
                if sum(len(i.payload) for i in images)>48*1024*1024:raise ProviderError('PREPARED_TOO_LARGE','Przygotowane zdjęcia są zbyt duże. Zmniejsz ich liczbę.',413)
                if not limits.allow('daily',cfg.max_per_day,86400):raise ProviderError('DAILY_LIMIT','Osiągnięto dzienny limit analiz kliniki.',429)
                # Record attempted call before provider: no silent automatic billed retries.
                completed.add(key)
                if len(completed)>10000:completed.clear();completed.add(key)
                result=await engine.analyze(images,case)
                validate_references(result.review,images)
                report=interpret(case,result.review,[i.metadata for i in images])
                report.update({'run_id':str(uuid.uuid4()),'created_at':datetime.now(timezone.utc).isoformat(),
                  'case':case.model_dump(exclude={'share_images'}),'provider':{'name':'OpenAI','model':result.model,'response_id':result.response_id},
                  'image_metadata':[i.metadata for i in images],'software_version':__version__,'prompt_version':PROMPT_VERSION,
                  'image_inference_completed':True,'trained_on_atlas':False})
                live_success=True
                return report
            finally:inflight.discard(key)
    @app.get('/')
    async def index():return FileResponse(ROOT/'web'/'index.html')
    app.mount('/',StaticFiles(directory=ROOT/'web'),name='web')
    return app
app=create_app()
