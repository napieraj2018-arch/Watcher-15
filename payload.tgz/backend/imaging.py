from __future__ import annotations

import hashlib
import io
import warnings
from dataclasses import dataclass, field

import numpy as np
from PIL import Image, ImageOps, ImageCms, UnidentifiedImageError

MAX_FILE_BYTES = 20 * 1024 * 1024
MAX_PIXELS = 52_000_000
MAX_EDGE = 4096
MIN_EDGE = 256
ALLOWED_FORMATS = {"JPEG", "PNG", "WEBP", "TIFF"}
try:
    from pillow_heif import register_heif_opener
    register_heif_opener()
    ALLOWED_FORMATS.add("HEIF")
except ImportError:
    pass


class ImageInputError(ValueError):
    pass


@dataclass
class PreparedImage:
    image_id: str
    original: bytes = field(repr=False)
    payload: bytes = field(repr=False)
    mime_type: str
    metadata: dict


def prepare_image(raw: bytes, index: int) -> PreparedImage:
    """Validate bytes, preserve evidence hashes, normalize orientation, remove EXIF.

    No sharpening, generated upscaling, cell synthesis, color enhancement or OCR.
    Technical scores are exploratory flags, not validated cytology quality thresholds.
    """
    if not raw or len(raw) > MAX_FILE_BYTES:
        raise ImageInputError("Pusty plik albo plik większy niż 20 MB.")
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            with Image.open(io.BytesIO(raw)) as source:
                fmt = source.format
                if fmt not in ALLOWED_FORMATS:
                    raise ImageInputError("Obsługiwane są JPG, PNG, WebP i pojedyncze TIFF. HEIC wymaga aktywnego dekodera na serwerze.")
                if getattr(source, "n_frames", 1) != 1:
                    raise ImageInputError("Wybierz pojedyncze zdjęcie; animacje i wielostronicowe TIFF nie są obsługiwane.")
                width, height = source.size
                if width * height > MAX_PIXELS:
                    raise ImageInputError("Obraz przekracza limit 52 megapikseli. Wyeksportuj mniejszy plik.")
                if source.mode in {"I", "F", "I;16", "I;16B", "I;16L"}:
                    raise ImageInputError("Obraz 16/32-bitowy wymaga świadomego eksportu do 8-bitowego sRGB.")
                source.load()
                icc = source.info.get("icc_profile")
                img = ImageOps.exif_transpose(source)
                actions = ["Usunięto metadane EXIF z kopii wysyłanej; oryginalny plik i jego SHA-256 bez zmian."]
                if img.mode in ("RGBA", "LA") or (img.mode == "P" and "transparency" in img.info):
                    rgba = img.convert("RGBA")
                    background = Image.new("RGBA", rgba.size, (255, 255, 255, 255))
                    img = Image.alpha_composite(background, rgba).convert("RGB")
                    actions.append("Kanał alfa złożono na białym tle.")
                else:
                    img = img.convert("RGB")
                if icc:
                    try:
                        img = ImageCms.profileToProfile(img, ImageCms.ImageCmsProfile(io.BytesIO(icc)), ImageCms.createProfile("sRGB"), outputMode="RGB")
                        actions.append("Profil barwny przeliczono do sRGB, bez wzmacniania koloru.")
                    except (ValueError, OSError, ImageCms.PyCMSError):
                        raise ImageInputError("Nieprawidłowy profil koloru; wyeksportuj poprawną kopię sRGB.")
                oriented_size = img.size
                if max(img.size) > MAX_EDGE:
                    img.thumbnail((MAX_EDGE, MAX_EDGE), Image.Resampling.LANCZOS)
                    actions.append(f"Zmniejszono z {oriented_size[0]}×{oriented_size[1]} do {img.width}×{img.height}; oryginał zachowany u użytkownika.")
                probe = img.copy()
                probe.thumbnail((768, 768), Image.Resampling.LANCZOS)
                gray = np.asarray(probe.convert("L"), dtype=np.float32)
                if min(gray.shape) < 3:
                    raise ImageInputError("Zbyt mały obraz.")
                center = gray[1:-1, 1:-1]
                lap = gray[:-2,1:-1] + gray[2:,1:-1] + gray[1:-1,:-2] + gray[1:-1,2:] - 4 * center
                sharpness = float(lap.var())
                contrast = float(gray.std())
                extreme_fraction = float(np.mean((gray < 3) | (gray > 252)))
                flags = []
                hard_stop = False
                if min(img.size) < MIN_EDGE:
                    flags.append("Mniejszy wymiar <256 px; za mało danych do tego modułu.")
                    hard_stop = True
                if contrast < 1.5:
                    flags.append("Prawie jednolite pole — obraz bez wystarczającej informacji.")
                    hard_stop = True
                if sharpness < 12:
                    flags.append("Niski wskaźnik krawędzi/ostrości; wskaźnik nie jest zwalidowany dla mikrofotografii.")
                if extreme_fraction > 0.50:
                    flags.append("Duża część pola jest bardzo jasna lub ciemna; możliwe tło / winieta / prześwietlenie.")
                # Regenerate a pixel-only image to prevent embedded EXIF/text/profile chunks leaking.
                clean = Image.frombytes("RGB", img.size, img.tobytes())
                out = io.BytesIO()
                clean.save(out, format="PNG")
                payload = out.getvalue()
                raw_hash = hashlib.sha256(raw).hexdigest()
                metadata = {
                    "image_id": f"I{index:02d}",
                    "original_sha256": raw_hash,
                    "sent_sha256": hashlib.sha256(payload).hexdigest(),
                    "original_width": width, "original_height": height,
                    "sent_width": clean.width, "sent_height": clean.height,
                    "original_format": fmt, "original_bytes": len(raw), "sent_bytes": len(payload),
                    "technical_flags": flags, "technical_hard_stop": hard_stop,
                    "laplacian_variance_exploratory": round(sharpness, 2),
                    "gray_std_exploratory": round(contrast, 2),
                    "extreme_fraction": round(extreme_fraction, 4),
                    "transforms": actions,
                    "quality_thresholds_clinically_validated": False,
                }
                return PreparedImage(f"I{index:02d}", raw, payload, "image/png", metadata)
    except ImageInputError:
        raise
    except (UnidentifiedImageError, OSError, ValueError, Image.DecompressionBombError, Image.DecompressionBombWarning) as exc:
        raise ImageInputError("Nie można bezpiecznie odczytać pliku obrazu.") from exc
