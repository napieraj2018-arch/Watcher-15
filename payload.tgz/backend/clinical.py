from __future__ import annotations
from .models import ANATOMY, FEATURES, CYTOLOGY_CODES, CaseInput, VisualReview

SOURCES = [
 {'id':'ESAVS_F23','title':'ESAVS 2026 — Ocular cytology, Esther Torrent Galindo',
  'url':'https://drive.google.com/file/d/1to0u7OkCrKuw4oMQj4AcOKv1afgCXbG8/view',
  'scope':'Materiał dostarczony przez klinikę: cytologia, artefakty, ograniczenia. Nie waliduje modelu.'},
 {'id':'EXAM_CAT2016','title':'Eye examination in the cat: Step-by-step approach and common findings',
  'url':'https://pmc.ncbi.nlm.nih.gov/articles/PMC11148898/',
  'scope':'Publiczne źródło dla badania kota; nie pomiar skuteczności programu.'},
 {'id':'EXAM_DOGCAT','title':'Ophthalmic examination in dogs and cats. Part I.',
  'url':'https://ejournals.epublishing.ekt.gr/index.php/jhvms/article/view/15262',
  'scope':'Publiczne źródło: badanie obu oczu, techniki i ograniczenia obrazowania.'},
 {'id':'FUNDUS2025','title':'Fundoscopy in cats: a practical guide and common findings',
  'url':'https://pmc.ncbi.nlm.nih.gov/articles/PMC12065995/',
  'scope':'Publiczne opracowanie dna oka kota; nie przenosić automatycznie wariantów na psa.'},
 {'id':'HILLSTROM2012','title':'Evaluation of cytologic findings in feline conjunctivitis',
  'url':'https://pubmed.ncbi.nlm.nih.gov/22551068/',
  'scope':'Badanie spojówki kota. Cytologia nie potwierdza wiarygodnie Mycoplasma; nie badanie rogówki.'},
]
ALLOWED = {
 'eyelids':{'external','slit_lamp'}, 'conjunctiva':{'external','slit_lamp','fluorescein'},
 'tear_film':{'external','slit_lamp','fluorescein'}, 'cornea':{'external','slit_lamp','fluorescein'},
 'anterior_chamber':{'slit_lamp','external','ultrasound'}, 'iris_pupil':{'slit_lamp','external'},
 'lens':{'slit_lamp','ultrasound','external'}, 'vitreous':{'fundus','ultrasound'},
 'retina_choroid':{'fundus','ultrasound'}, 'optic_disc':{'fundus'}, 'orbit_globe':{'external','ultrasound'},
}
FUNDUS_CODES={'retinal_hemorrhage','tapetal_change','optic_disc_change','retinal_vessel_change'}

def gate_review(review:VisualReview,metadata:list[dict]):
    out=review.model_copy(deep=True); notes=[]
    meta={m['image_id']:m for m in metadata}; image_map={i.image_id:i for i in out.images}
    for i in out.images:
        if meta[i.image_id]['technical_hard_stop']:
            i.adequacy='inadequate'; i.limitations.append('Kontrola techniczna: niediagnostyczny plik.')
    def usable(ids,kinds):
        return [i for i in ids if image_map[i].kind in kinds and image_map[i].adequacy!='inadequate']
    for a in out.anatomy:
        if a.visibility not in ('visible','partial'): continue
        ids=usable(a.image_ids,ALLOWED[a.structure])
        if not ids:
            a.visibility='not_visible'; a.image_ids=[]
            a.description='Brak ocenialnego obrazu odpowiedniej modalności; bez wniosku o prawidłowości.'
            notes.append('Nie potwierdzono widoczności: '+ANATOMY[a.structure]+'.')
        elif a.structure in ('tear_film','orbit_globe') or (a.structure in ('anterior_chamber','lens') and all(image_map[i].kind=='external' for i in ids)):
            a.visibility='partial'
            a.description+=' Ocena częściowa; zdjęcie nie zastępuje odpowiedniego badania klinicznego.'
        elif any(image_map[i].adequacy=='limited' for i in ids): a.visibility='partial'
    for f in out.findings:
        if f.code in CYTOLOGY_CODES: kinds={'cytology'}
        elif f.code in FUNDUS_CODES: kinds={'fundus'}
        elif f.code=='retinal_detachment_suspicion': kinds={'fundus','ultrasound'}
        elif f.code=='ultrasound_membrane': kinds={'ultrasound'}
        elif f.code=='vitreous_opacity': kinds={'fundus','ultrasound'}
        elif f.code=='fluorescein_uptake': kinds={'fluorescein'}
        else: kinds={'external','slit_lamp','fluorescein'}
        ids=usable(f.image_ids,kinds)
        if f.state in ('seen','uncertain','not_seen') and not ids:
            f.state='not_assessable'; f.description='Brak odpowiedniej, ocenialnej modalności. Nie określono obecności ani nieobecności cechy.'
            f.image_ids=[]
        elif f.state=='seen' and not any(image_map[i].adequacy=='adequate' for i in ids):
            f.state='uncertain'; notes.append(FEATURES[f.code]+': ograniczona jakość — obserwacja niejednoznaczna.')
    return out,notes

def interpret(case:CaseInput,review:VisualReview,metadata:list[dict]):
    r,notes=gate_review(review,metadata)
    present={f.code:f for f in r.findings if f.state in ('seen','uncertain')}
    visible=[i for i in r.images if i.kind not in ('other','uncertain') and i.adequacy!='inadequate']
    alerts=[]; diffs=[]; missing=[]
    def alert(level,text,basis): alerts.append({'level':level,'text':text,'basis':basis})
    if case.severe_pain or case.sudden_vision_loss:
        alert('urgent','Silny ból lub nagła utrata widzenia: pilne badanie okulistyczne. Nie czekaj na raport AI.','Dane wpisane przez użytkownika')
    if case.ulcer_depth in ('głęboki','perforacja') or case.melting:
        alert('urgent','Zagrożona integralność rogówki: bez ucisku i rutynowego skrobania miejsca ścieńczenia; pilna kwalifikacja okulistyczna.','Dane wpisane przez użytkownika')
    if case.fluorescein=='dodatnia' or case.ulcer_depth in ('powierzchowny','głęboki','perforacja'):
        alert('warning','Zgłoszono ubytek nabłonka. Raport nie jest podstawą do włączenia miejscowego kortykosteroidu.','Dane wpisane przez użytkownika')
    if case.fluorescein=='dodatnia' and case.ulcer_depth=='brak':
        alert('warning','Niespójne dane: dodatnia fluoresceina i zaznaczony brak ubytku. Zweryfikuj wyniki.','Kontrola spójności formularza')
    if set(present)&{'descemetocele_suspicion','lens_displacement_suspicion','retinal_detachment_suspicion'}:
        alert('urgent','Na obrazach zgłoszono podejrzenie zmiany zagrażającej widzeniu. To sygnał do pilnego badania, nie potwierdzone rozpoznanie.','Niezależnie niezweryfikowana obserwacja modelu')
    if case.eye=='nieustalone': missing.append('Nie oznaczono oka OD/OS; nie wnioskuję strony ze zdjęcia.')
    if case.mode=='cytology' and case.sample_site=='nieustalone': missing.append('Nie podano dokładnego miejsca pobrania cytologii.')
    if case.mode in ('whole_eye','anterior'):
        if case.fluorescein=='niebadana': missing.append('Brak wyniku fluoresceiny — nie ustalono integralności nabłonka.')
        if case.iop is None: missing.append('Brak pomiaru IOP; zdjęcie nie mierzy ciśnienia w oku.')
        if case.stt is None: missing.append('Nie podano STT; zdjęcie nie mierzy produkcji łez.')
    expected={'whole_eye':{'external','slit_lamp','fluorescein','fundus','cytology','ultrasound'},'anterior':{'external','slit_lamp','fluorescein'},'fundus':{'fundus'},'cytology':{'cytology'},'ultrasound':{'ultrasound'}}[case.mode]
    mismatch=not any(i.kind in expected and i.adequacy!='inadequate' for i in r.images)
    if mismatch:
        alert('warning','Typ przesłanych obrazów nie pozwala wykonać wybranego trybu badania. Zmień tryb lub dodaj odpowiednie zdjęcia.','Kontrola modalności')
    def add(code,title,keys,tests,caveats,source='EXAM_DOGCAT'):
        hit=[k for k in keys if k in present]
        if not hit:return
        diffs.append({'code':code,'title':title,'status':'hipoteza — niepotwierdzona',
            'evidence':[FEATURES[k]+' ('+present[k].state+'; '+', '.join(present[k].image_ids)+')' for k in hit],
            'next_tests':tests,'limitations':caveats,'source_ids':[source]})
    add('ocular_surface','Zmiana powierzchni oka: zapalna, urazowa lub związana z filmem łzowym',
        ['corneal_opacity','corneal_vessels','surface_defect_suspicion','fluorescein_uptake','conjunctival_redness'],
        ['Badanie w powiększeniu, fluoresceina oraz ocena głębokości i dynamiki zmiany.','STT i IOP według wskazań i bezpieczeństwa badania.'],
        ['Zmętnienie nie identyfikuje zakażenia; fotografia nie określa wiarygodnie głębokości ubytku.'])
    add('adnexa','Zmiana powiek lub spojówki wymagająca oceny przydatków',
        ['eyelid_mass','entropion_suspicion','globe_position_change'],
        ['Dokładne badanie brzegów powiek, spojówki i trzeciej powieki.','Przy utrzymującym się rozroście: cytologia lub histopatologia zależnie od wskazań.'],
        ['Wygląd fotografii nie ustala typu nowotworu ani stanu oczodołu.'])
    add('anterior','Zmiana komory przedniej / tęczówki; rozważ zapalenie lub krwawienie',
        ['hyphema','hypopyon','pupil_shape_change'],
        ['Lampa szczelinowa, pomiar IOP i badanie całego oka oraz przyczyn ogólnych.'],
        ['Nieruchome zdjęcie nie bada odruchów źrenicznych ani widzenia.'])
    add('lens','Zmętnienie lub nieprawidłowe położenie w projekcji soczewki',
        ['lens_opacity','lens_displacement_suspicion'],
        ['Badanie soczewki w lampie szczelinowej; dodatkowe obrazowanie według wskazań.'],
        ['Odbłysk, rogówka i soczewka mogą się nakładać; nie utożsamiaj każdej bieli z zaćmą.'])
    add('fundus','Zmiana dna oka wymagająca pełnego badania tylnego odcinka',
        ['retinal_hemorrhage','retinal_detachment_suspicion','tapetal_change','optic_disc_change','retinal_vessel_change','vitreous_opacity'],
        ['Fundoskopia obu oczu i pomiar ciśnienia tętniczego w odpowiednim kontekście.','Przy nieprzejrzystych ośrodkach: USG; dalsze testy zależnie od wywiadu i funkcji wzrokowej.'],
        ['Pojedynczy kadr nie wyklucza zmian poza polem ani nie ustala ich etiologii.'],'FUNDUS2025' if case.species=='kot' else 'EXAM_DOGCAT')
    add('ultrasound','Nieprawidłowa struktura w USG — interpretacja wymaga pełnego badania',
        ['ultrasound_membrane'],['Ocena w kilku płaszczyznach i sekwencji dynamicznej z metadanymi aparatu.'],
        ['Pojedynczy kadr nie rozstrzyga siatkówka vs błony ciała szklistego vs artefakt.'])
    add('bacterial_cytology','Wzorzec bakteriopodobny: zakażenie, nakładanie struktur lub zanieczyszczenie',
        ['intracellular_bacteria','extracellular_cocci','extracellular_rods'],
        ['Ocena całego preparatu; posiew z antybiogramem przy klinicznym wskazaniu.'],
        ['Morfologia nie ustala gatunku i lekowrażliwości; brak bakterii w polu nie wyklucza zakażenia.'],'ESAVS_F23')
    if case.species=='kot':
        add('granules','Mycoplasma / Chlamydia lub imitujące je struktury — nie rozpoznanie gatunku',
            ['small_basophilic_clusters','perinuclear_inclusions'],
            ['Porównaj inne pola, pigment, osad, leki i granule komórkowe.','PCR z właściwego miejsca, jeżeli wynik zmienia postępowanie.'],
            ['Dane diagnostyczne dotyczą głównie spojówki; nie przenosić ich bezpośrednio na rogówkę.','Dodatni PCR nie dowodzi samodzielnie przyczynowości każdej zmiany.'],'HILLSTROM2012')
        add('eosinophilic','Wzorzec eozynofilowy; w odpowiednim kontekście rozważ FEK',
            ['eosinophils'],['Korelacja z wyglądem rogówki/spojówki, fluoresceiną i pozostałymi polami preparatu.'],
            ['Same wolne ziarnistości lub mastocyty nie potwierdzają FEK.'],'ESAVS_F23')
    add('fungal','Struktury grzybopodobne — do potwierdzenia',
        ['fungal_hyphae','yeast_like_structures'],['Odczyt szkiełka i diagnostyka mykologiczna zależnie od lokalizacji.'],
        ['Włókna i artefakty mogą imitować grzyby; bez oznaczenia gatunku ze zdjęcia.'],'ESAVS_F23')
    add('atypia','Atypia: zmiana odczynowa albo proces rozrostowy',
        ['cellular_atypia'],['Reprezentatywna próbka i ocena patomorfologiczna; histologia, gdy potrzebna architektura.'],
        ['Atypia zapalna może imitować nowotwór.'],'ESAVS_F23')
    add('inflammation','Naciek zapalny — typ komórek nie rozstrzyga etiologii',
        ['neutrophils','macrophages','lymphoplasmacytic_cells'],['Ocena komórek, tła i preparatu w połączeniu z obrazem klinicznym.'],
        ['Nie rozpoznawaj FHV-1 na podstawie samych neutrofili.'],'ESAVS_F23')
    no_image_basis=not visible or mismatch
    if no_image_basis: diffs=[]
    labels=[FEATURES[k] for k in present]
    summary=('Brak odpowiedniego materiału do wybranego badania. Nie utworzono rozpoznania.' if no_image_basis else
             ('Na przesłanych obrazach odnotowano: '+', '.join(labels[:5])+'. Obserwacje wymagają kontekstu klinicznego.' if labels else
              'Nie wskazano jednoznacznego wzorca w dostępnych polach. Nie jest to potwierdzenie prawidłowego oka.'))
    limitations=list(dict.fromkeys([
        'Model ogólnego przeznaczenia; skuteczność kliniczna tej aplikacji nie została zmierzona.',
        'Wynik dotyczy przesłanych zdjęć, nie całego oka ani całego preparatu. Brak zmian w polu nie wyklucza choroby.',
        *r.limitations,*notes,
    ]))
    return {'summary':summary,'assessment':'insufficient' if no_image_basis else 'draft_observations',
       'urgency':'urgent' if any(a['level']=='urgent' for a in alerts) else 'not_determined',
       'anatomy':[dict(a.model_dump(),label=ANATOMY[a.structure]) for a in r.anatomy],
       'images':[i.model_dump() for i in r.images],
       'findings':[dict(f.model_dump(),label=FEATURES[f.code]) for f in r.findings],
       'differentials':diffs,'alerts':alerts,'missing_data':missing,
       'suggested_views':r.suggested_views,'limitations':limitations,
       'sources':SOURCES,'clinically_validated':False,'autonomous_treatment':False}
