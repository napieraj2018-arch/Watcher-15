from __future__ import annotations
import base64, json
from dataclasses import dataclass
import httpx
from pydantic import ValidationError
from .models import VisualReview, CaseInput
from .imaging import PreparedImage
from .prompt import SYSTEM_PROMPT

class ProviderError(Exception):
    def __init__(self, code:str, message:str, status:int=502):
        super().__init__(code); self.code,self.message,self.status=code,message,status

@dataclass
class ProviderResult:
    review: VisualReview
    model: str
    response_id: str
    usage: dict

def validate_references(review:VisualReview, images:list[PreparedImage]):
    expected={i.image_id for i in images}; actual=[i.image_id for i in review.images]
    if set(actual)!=expected or len(actual)!=len(expected):
        raise ProviderError('IMAGE_REFERENCES','Model zwrócił niezgodne identyfikatory zdjęć. Wynik odrzucono.')
    for item in [*review.anatomy,*review.findings]:
        if not set(item.image_ids).issubset(expected):
            raise ProviderError('IMAGE_REFERENCES','Wynik odwołuje się do nieprzesłanego zdjęcia.')

class OpenAIVisionProvider:
    def __init__(self, api_key:str, model:str='gpt-6-astra', transport=None):
        self.api_key,self.model,self.transport=api_key,model,transport
    def payload(self, images:list[PreparedImage], case:CaseInput):
        # Owner identity, case ID, filenames, EXIF and tentative diagnoses are NOT sent.
        content=[{'type':'input_text','text':json.dumps({
            'task':'Opis obrazów, bez diagnozy ostatecznej',
            'untrusted_metadata':{'species':case.species,'stain':case.stain,'magnification':case.magnification},
        },ensure_ascii=False)}]
        for image in images:
            content.append({'type':'input_text','text':json.dumps({'image_id':image.image_id})})
            content.append({'type':'input_image','detail':'high',
                'image_url':f'data:{image.mime_type};base64,'+base64.b64encode(image.payload).decode('ascii')})
        payload={'model':self.model,'store':False,'instructions':SYSTEM_PROMPT,
            'input':[{'role':'user','content':content}], 'max_output_tokens':12000,
            'text':{'format':{'type':'json_schema','name':'okovet_whole_eye','strict':True,
                'schema':VisualReview.model_json_schema()}}}
        if self.model.startswith(('gpt-5','gpt-6')):
            payload['reasoning']={'effort':'medium'}
        return payload
    async def analyze(self,images:list[PreparedImage],case:CaseInput):
        if not self.api_key:
            raise ProviderError('NOT_CONFIGURED','Silnik obrazu nie jest jeszcze aktywny. Nie wykonano analizy.',503)
        try:
            async with httpx.AsyncClient(timeout=httpx.Timeout(180,connect=15),transport=self.transport,follow_redirects=False) as client:
                response=await client.post('https://api.openai.com/v1/responses',
                  headers={'Authorization':'Bearer '+self.api_key,'Content-Type':'application/json'},
                  json=self.payload(images,case))
        except httpx.TimeoutException as exc:
            raise ProviderError('PROVIDER_TIMEOUT','Brak odpowiedzi w limicie czasu. Nie ponawiam automatycznie płatnego zapytania.',504) from exc
        except httpx.HTTPError as exc:
            raise ProviderError('PROVIDER_NETWORK','Nie udało się połączyć z silnikiem obrazu.') from exc
        if response.status_code!=200:
            msg={400:'Dostawca odrzucił ustawienia modelu.',401:'Konfiguracja dostępu do modelu wymaga poprawy.',403:'Brak dostępu do wybranego modelu.',404:'Wybrany model jest niedostępny.',429:'Limit zapytań lub środków dostawcy został wyczerpany.'}
            raise ProviderError('PROVIDER_'+str(response.status_code),msg.get(response.status_code,'Silnik obrazu jest chwilowo niedostępny.'))
        try:
            raw=response.json()
            if raw.get('status')!='completed':
                raise ProviderError('INCOMPLETE','Analiza nie została ukończona. Nie utworzono raportu.')
            parts=[]
            for output in raw.get('output',[]):
                for part in output.get('content',[]):
                    if part.get('type')=='refusal':
                        raise ProviderError('REFUSED','Model nie podjął oceny zdjęć.')
                    if part.get('type')=='output_text': parts.append(part.get('text',''))
            review=VisualReview.model_validate_json(''.join(parts))
            validate_references(review,images)
            return ProviderResult(review,str(raw.get('model',self.model)),str(raw.get('id','')),raw.get('usage') or {})
        except ProviderError: raise
        except (ValueError,TypeError,ValidationError,KeyError) as exc:
            raise ProviderError('INVALID_MODEL_OUTPUT','Odpowiedź nie spełnia wymagań spójności. Nie przedstawiono jej jako wyniku badania.') from exc
