from __future__ import annotations
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, model_validator

class StrictModel(BaseModel):
    model_config = ConfigDict(extra='forbid')

Mode = Literal['whole_eye','anterior','fundus','cytology','ultrasound']
ImageKind = Literal['external','slit_lamp','fluorescein','fundus','cytology','ultrasound','other','uncertain']
ANATOMY = {
    'eyelids':'Powieki i przydatki', 'conjunctiva':'Spojówka i trzecia powieka',
    'tear_film':'Powierzchnia / film łzowy', 'cornea':'Rogówka',
    'anterior_chamber':'Komora przednia', 'iris_pupil':'Tęczówka i źrenica',
    'lens':'Soczewka', 'vitreous':'Ciało szkliste',
    'retina_choroid':'Siatkówka i naczyniówka', 'optic_disc':'Tarcza nerwu wzrokowego',
    'orbit_globe':'Położenie gałki / oczodół',
}
AnatomyCode = Literal['eyelids','conjunctiva','tear_film','cornea','anterior_chamber','iris_pupil','lens','vitreous','retina_choroid','optic_disc','orbit_globe']
FEATURES = {
 'conjunctival_redness':'Przekrwienie spojówki', 'eyelid_mass':'Zmiana rozrostowa powieki / spojówki',
 'entropion_suspicion':'Podejrzenie nieprawidłowego ustawienia powieki',
 'corneal_opacity':'Zmętnienie rogówki', 'corneal_vessels':'Naczynia rogówki',
 'surface_defect_suspicion':'Podejrzenie ubytku powierzchni rogówki',
 'fluorescein_uptake':'Widoczne barwienie fluoresceiną',
 'descemetocele_suspicion':'Podejrzenie krytycznego ścieńczenia rogówki',
 'hyphema':'Materiał zgodny z krwią w komorze przedniej', 'hypopyon':'Materiał przypominający ropostek',
 'pupil_shape_change':'Zmieniony kształt źrenicy', 'lens_opacity':'Zmętnienie w projekcji soczewki',
 'lens_displacement_suspicion':'Podejrzenie zmiany położenia soczewki',
 'retinal_hemorrhage':'Krwotok na dnie oka', 'retinal_detachment_suspicion':'Podejrzenie odwarstwienia siatkówki',
 'tapetal_change':'Zmiana odblaskowości dna', 'optic_disc_change':'Zmiana tarczy nerwu wzrokowego',
 'retinal_vessel_change':'Zmiana naczyń siatkówki', 'vitreous_opacity':'Nieprzejrzystość w ciele szklistym',
 'globe_position_change':'Zmiana położenia gałki', 'ultrasound_membrane':'Struktura błoniasta w USG',
 'epithelial_cells':'Komórki nabłonkowe', 'neutrophils':'Neutrofile',
 'degenerate_neutrophils':'Neutrofile z cechami degeneracji',
 'intracellular_bacteria':'Struktury bakteriopodobne wewnątrz komórek zapalnych',
 'extracellular_cocci':'Ziarniakopodobne struktury w tle', 'extracellular_rods':'Pałeczkopodobne struktury w tle',
 'small_basophilic_clusters':'Skupiska drobnych bazofilnych struktur',
 'perinuclear_inclusions':'Okołojądrowe wtręty cytoplazmatyczne',
 'eosinophils':'Eozynofile', 'mast_cells':'Mastocyty', 'free_granules':'Wolne ziarnistości',
 'fungal_hyphae':'Strzępkopodobne struktury', 'yeast_like_structures':'Struktury drożdżakopodobne',
 'melanin':'Pigment melaniny', 'stain_precipitate':'Możliwy osad barwnika',
 'macrophages':'Makrofagi', 'lymphoplasmacytic_cells':'Komórki limfoplazmocytarne',
 'cellular_atypia':'Atypia komórkowa', 'nuclear_streaming':'Rozpad komórek / strumieniowanie jąder',
}
FeatureCode = Literal['conjunctival_redness','eyelid_mass','entropion_suspicion','corneal_opacity','corneal_vessels','surface_defect_suspicion','fluorescein_uptake','descemetocele_suspicion','hyphema','hypopyon','pupil_shape_change','lens_opacity','lens_displacement_suspicion','retinal_hemorrhage','retinal_detachment_suspicion','tapetal_change','optic_disc_change','retinal_vessel_change','vitreous_opacity','globe_position_change','ultrasound_membrane','epithelial_cells','neutrophils','degenerate_neutrophils','intracellular_bacteria','extracellular_cocci','extracellular_rods','small_basophilic_clusters','perinuclear_inclusions','eosinophils','mast_cells','free_granules','fungal_hyphae','yeast_like_structures','melanin','stain_precipitate','macrophages','lymphoplasmacytic_cells','cellular_atypia','nuclear_streaming']
CYTOLOGY_CODES = set(list(FEATURES)[21:])

class CaseInput(StrictModel):
    case_id: str = Field(min_length=1, max_length=60, pattern=r'^[\w .\-]+$')
    species: Literal['kot','pies']
    eye: Literal['OD','OS','nieustalone'] = 'nieustalone'
    mode: Mode = 'whole_eye'
    sample_site: Literal['nieustalone','rogówka','spojówka','powieka','ciecz wodnista','ciało szkliste'] = 'nieustalone'
    stt: float | None = Field(default=None, ge=0, le=100)
    iop: float | None = Field(default=None, ge=0, le=150)
    fluorescein: Literal['niebadana','ujemna','dodatnia'] = 'niebadana'
    ulcer_depth: Literal['nieustalona','brak','powierzchowny','głęboki','perforacja'] = 'nieustalona'
    severe_pain: bool = False
    sudden_vision_loss: bool = False
    trauma: bool = False
    melting: bool = False
    duration: str = Field(default='', max_length=100)
    history: str = Field(default='', max_length=2000)
    stain: str = Field(default='nieznane', max_length=80)
    magnification: str = Field(default='nieznane', max_length=80)
    share_images: bool = False

class ImageAssessment(StrictModel):
    image_id: str
    kind: ImageKind
    adequacy: Literal['adequate','limited','inadequate']
    description: str
    limitations: list[str]

class AnatomyAssessment(StrictModel):
    structure: AnatomyCode
    visibility: Literal['visible','partial','not_visible','not_applicable']
    description: str
    image_ids: list[str]

class Finding(StrictModel):
    code: FeatureCode
    state: Literal['seen','uncertain','not_seen','not_assessable']
    description: str
    image_ids: list[str]

class VisualReview(StrictModel):
    images: list[ImageAssessment]
    anatomy: list[AnatomyAssessment]
    findings: list[Finding]
    summary: str
    limitations: list[str]
    suggested_views: list[str]

    @model_validator(mode='after')
    def check_structure(self):
        if len(self.images) > 6 or len(self.findings)>len(FEATURES):
            raise ValueError('Nieprawidłowa liczba wyników.')
        ids = [a.structure for a in self.anatomy]
        if set(ids) != set(ANATOMY) or len(ids)!=len(ANATOMY):
            raise ValueError('Wymagane dokładnie 11 struktur, także niewidocznych.')
        codes=[f.code for f in self.findings]
        if len(codes)!=len(set(codes)):
            raise ValueError('Powtórzone cechy.')
        for f in self.findings:
            if f.state in ('seen','uncertain') and not f.image_ids:
                raise ValueError('Obserwacja musi wskazywać zdjęcie.')
        for a in self.anatomy:
            if a.visibility in ('visible','partial') and not a.image_ids:
                raise ValueError('Widoczna struktura wymaga dowodu obrazowego.')
        if not self.summary.strip():
            raise ValueError('Pusty opis.')
        return self
