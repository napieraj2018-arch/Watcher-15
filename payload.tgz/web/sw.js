'use strict';
const CACHE='okovet-shell-v3.3.0';
const SHELL=['/','/index.html','/style.css','/app.js','/manifest.webmanifest','/assets/icon-192.png','/assets/icon-512.png','/assets/atlas.json'];
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
 const u=new URL(event.request.url);
 // Patient data, authorization and AI responses must never enter service-worker caches.
 if(event.request.method!=='GET'||u.origin!==self.location.origin||u.pathname.startsWith('/api/')||u.pathname==='/healthz')return;
 if(event.request.mode==='navigate'){
   event.respondWith(fetch(event.request).catch(()=>caches.match('/index.html')));return;
 }
 if(!SHELL.includes(u.pathname)&&!u.pathname.startsWith('/assets/atlas/'))return;
 event.respondWith(caches.match(event.request).then(cached=>cached||fetch(event.request).then(response=>{
   if(response.ok&&response.type==='basic'){const copy=response.clone();event.waitUntil(caches.open(CACHE).then(c=>c.put(event.request,copy)));}
   return response;
 })));
});
